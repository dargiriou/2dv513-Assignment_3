package model;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDatabase {

	
	private Connection c;
	CreateDatabase(Connection c)
	{
		this.c = c;
	}
	
	private String BOOKS = "BOOKS";
	private String AUTHORS = "AUTHORS";
	private String MEMBERS = "MEMBERS";
	private String BRANCH = "BRANCH";
	private String RESERVATIONS = "RESERVATIONS";
	private String PUBLISHERS = "PUBLISHER";
	
	public void createTables() {  
        Statement stmnt;
        String query;

        try {
        	stmnt = c.createStatement();
        	query = "CREATE TABLE IF NOT EXISTS " + BOOKS +
                    "( isbn TEXT PRIMARY KEY, " +
            		"title TEXT NOT NULL ," +
                    "publishers TEXT NOT NULL ,"+
                    "authors TEXT NOT NULL ,"+
                    "branch TEXT NOT NULL ,"+
                    "copies INT NOT NULL ," +
                    "FOREIGN KEY(publishers) REFERENCES PUBLISHERS (name) ON DELETE CASCADE)";          		
            stmnt.executeUpdate(query);
            stmnt.close();

            stmnt = c.createStatement();
            query = "CREATE TABLE IF NOT EXISTS " + RESERVATIONS +
                    " (date_in DATE NOT NULL ," +
                    "due_date DATE NOT NULL , " +
                    "isbn INT NOT NULL ," +
                    "branch_id INT NOT NULL ," +
                    "memberCard_num INT NOT NULL )";
            stmnt.executeUpdate(query);
            stmnt.close();

            stmnt = c.createStatement();
            query = "CREATE TABLE IF NOT EXISTS " + AUTHORS +
                    "( name TEXT PRIMARY KEY," +
                    "isbn INT NOT NULL )";
            stmnt.executeUpdate(query);
            stmnt.close();
            
            stmnt = c.createStatement();
            query = "CREATE TABLE IF NOT EXISTS " + PUBLISHERS +
                    "( name TEXT PRIMARY KEY," +
                    "address TEXT NOT NULL ," +
                    "phone_num INT NOT NULL)";
            stmnt.executeUpdate(query);
            stmnt.close();
            
            stmnt = c.createStatement();
            query = "CREATE TABLE IF NOT EXISTS " + BRANCH +
                    "( name TEXT PRIMARY KEY," +
                    "id INT NOT NULL )";
            stmnt.executeUpdate(query);
            stmnt.close();
            
            stmnt = c.createStatement();
            query = "CREATE TABLE IF NOT EXISTS " + MEMBERS +
                    " (card_number TEXT PRIMARY KEY ," +
                    "name TEXT NOT NULL , " +
                    "address TEXT NOT NULL ," +
                    "phone_num INT NOT NULL )";
            stmnt.executeUpdate(query);
            stmnt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
}
}
