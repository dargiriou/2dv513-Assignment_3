package view;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.BooksData;
import model.DBConnection;
import model.MembersData;

public class MembersController implements Initializable {
	
	@FXML
	private TextField nameField;
	@FXML 
	private TextField surnameField;
	@FXML
	private TextField memberIDField;
	@FXML
	private TextField emailField;
	@FXML
	private TextField addressField;
	@FXML
	private TextField phoneNumberField;
	@FXML
	private TextField search;
	
	@FXML
	private TableView<BooksData> booksTable;
	@FXML
	private TableColumn<BooksData, String> isbnColumn;
	@FXML
	private TableColumn<BooksData, String> titleColumn;
	@FXML
	private TableColumn<BooksData, String> authorColumn;
	@FXML
	private TableColumn<BooksData, String> publisherColumn;
	@FXML
	private TableColumn<BooksData, String> branchColumn;
	@FXML
	private TableColumn<BooksData, Integer> copiesColumn;
	@FXML
	private Button addMemberBtn;
	@FXML
	private Button deleteMemberBtn;
	@FXML
	private Button clearFormBtn;
	@FXML
	private Button updateMemberButton;
	
	@FXML
	private ChoiceBox<String> choiceBox1id;
	
	private ObservableList<MembersData> data;
	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		choiceBox1id.setValue("Name");
		choiceBox1id.getItems().add("Surname");
		choiceBox1id.getItems().add("Member ID");
		choiceBox1id.getItems().add("Email");
		choiceBox1id.getItems().add("Address");
		choiceBox1id.getItems().add("Phone number");
		
	}
	
	@FXML
	private void handleClearButton(ActionEvent event)
	{
		this.nameField.setText("");
		this.surnameField.setText("");
		this.memberIDField.setText("");
		this.emailField.setText("");
		this.addressField.setText("");
		this.phoneNumberField.setText("");
	}
	
	private void LoadDatabaseData()
	{
		try {
			Connection conn = DBConnection.getConnection();
			this.data = FXCollections.observableArrayList();
			
			ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM BOOKS");
			while(rs.next())
			{
				this.data.add(new BooksData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6)));
			}
		} catch (SQLException e) {
			System.err.println("Error" + e);
		}
		
		this.nameColumn.setCellValueFactory(new PropertyValueFactory<BooksData, String>("isbn"));
		this.surnameColumn.setCellValueFactory(new PropertyValueFactory<BooksData, String>("title"));
		this.memberIDColumn.setCellValueFactory(new PropertyValueFactory<BooksData, String>("author"));
		this.emailColumn.setCellValueFactory(new PropertyValueFactory<BooksData, String>("publisher"));
		this.addressColumn.setCellValueFactory(new PropertyValueFactory<BooksData, String>("branch"));
		this.phoneColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getNumOfCopies()).asObject());
		
		this.booksTable.setItems(null);
		this.booksTable.setItems(this.data);

	}

}
